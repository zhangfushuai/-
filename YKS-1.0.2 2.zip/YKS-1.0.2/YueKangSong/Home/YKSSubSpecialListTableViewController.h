//
//  YKSSpecialListTableViewController.h
//  YueKangSong
//
//  Created by gongliang on 15/5/14.
//  Copyright (c) 2015年 YKS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YKSSpecial.h"

@interface YKSSubSpecialListTableViewController : UITableViewController

@property (nonatomic, strong) YKSSpecial *special;

@end
