//
//  QRView.h
//  
//
//  Created by gongliang on 15/4/25.
//  Copyright (c) 2015年 gongliang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QRView : UIView
/**
 *  透明的区域
 */
@property (nonatomic, assign) CGSize transparentArea;
@end
