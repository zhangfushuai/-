//
//  YKSMyInfoDetailVC.h
//  YueKangSong
//
//  Created by gongliang on 15/5/28.
//  Copyright (c) 2015年 YKS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YKSMyInfoDetailVC : UITableViewController

@end
