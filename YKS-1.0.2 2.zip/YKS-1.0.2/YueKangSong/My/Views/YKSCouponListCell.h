//
//  YKSCouponListCell.h
//  YueKangSong
//
//  Created by gongliang on 15/5/27.
//  Copyright (c) 2015年 YKS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YKSCouponListCell : UITableViewCell
//@property (weak, nonatomic) IBOutlet UILabel *priceLabel;
//@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
//@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
//@property (weak, nonatomic) IBOutlet UIImageView *topImageView;
//@property (weak, nonatomic) IBOutlet UIView *bgView;





@property (weak, nonatomic) IBOutlet UILabel *pricelabel;
@property (weak, nonatomic) IBOutlet UILabel *atitlelabel;
@property (weak, nonatomic) IBOutlet UILabel *btitlelabel;
@property (weak, nonatomic) IBOutlet UIImageView *backimage;

@end
