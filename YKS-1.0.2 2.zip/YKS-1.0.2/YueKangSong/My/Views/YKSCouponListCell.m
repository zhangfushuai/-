//
//  YKSCouponListCell.m
//  YueKangSong
//
//  Created by gongliang on 15/5/27.
//  Copyright (c) 2015年 YKS. All rights reserved.
//

#import "YKSCouponListCell.h"
@interface YKSCouponListCell ()

@end

@implementation YKSCouponListCell

- (void)awakeFromNib {
    // Initialization code
//    self.bgView.layer.masksToBounds = YES;
//    self.bgView.layer.cornerRadius = 5.0f;
}



//- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
//    [super setSelected:selected animated:animated];
//
//    // Configure the view for the selected state
//}

@end
