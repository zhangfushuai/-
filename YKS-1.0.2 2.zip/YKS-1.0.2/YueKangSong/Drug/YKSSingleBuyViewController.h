//
//  YKSSingleBuyViewController.h
//  YueKangSong
//
//  Created by gongliang on 15/5/21.
//  Copyright (c) 2015年 YKS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YKSSingleBuyViewController : UIViewController

@property (nonatomic, strong) NSDictionary *drugInfo;

@end
