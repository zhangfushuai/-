//
//  YKSDrug.h
//  YueKangSong
//
//  Created by gongliang on 15/5/14.
//  Copyright (c) 2015年 YKS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YKSDrug : NSObject

//@property (nonatomic, copy) NSString *gid; //商品Id

@end
