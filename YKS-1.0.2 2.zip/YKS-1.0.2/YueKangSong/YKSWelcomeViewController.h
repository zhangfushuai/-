//
//  GZWelcomeViewController.h
//  GZTour
//
//  Created by gongliang on 15/6/30.
//  Copyright (c) 2014年 gl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YKSWelcomeViewController : UIViewController

@end
